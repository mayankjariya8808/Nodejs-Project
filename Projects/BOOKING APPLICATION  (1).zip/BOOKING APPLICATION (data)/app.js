const express=require('express')
const port=8808;
const app=express()
const database=require('./config/database')
const Schema=require('./model/schema')
const path=require('path')
app.use('/',express.static(path.join(__dirname,"public")))
app.use(express.urlencoded())








app.set('view engine','ejs')
app.get('/',(req,res)=>{
    res.render('index')
})

app.get('/about.html',(req,res)=>{
    res.render('about')
})
app.get('/blog.html',(req,res)=>{
    res.render('blog')
})
app.get('/contact.html',(req,res)=>{
    res.render('contact')
})
app.get('/car.html',(req,res)=>{
    res.render('car')
})
app.get('/pricing.html',(req,res)=>{
    res.render('pricing')
})
app.get('/services.html',(req,res)=>{
    res.render('service')
})

app.post('/insert',(req,res)=>{
        Schema.create({
            name:req.body.name,
            mobile:req.body.mobile,
            picup:req.body.pickup,
            drop:req.body.drop,
            date1:req.body.date1,
            time:req.body.time,
            date2:req.body.date2,

})
res.redirect('/')
})
app.get('/view',(req,res)=>{

    Schema.find({}).then((alldata)=>{
        res.render('view',{
            data:alldata
        })
    })
    
})

app.get('/delete',(req,res)=>{
    
    let id=req.query.id;
    Schema.findByIdAndDelete(id).then(()=>{
        res.redirect('/view')
    })
})

app.get('/edit',(req,res)=>{
    let id=req.query.id
    Schema.findById(id).then((alldata)=>{
        res.render('edit',{
            editData:alldata
        })
    })
})

app.post('/update',(req,res)=>{
    let id=req.body.id
    Schema.findByIdAndUpdate(id,{
        name:req.body.name,
        mobile:req.body.mobile,
        pickup:req.body.pickup,
        drop:req.body.drop,
        date1:req.body.date1,
        date2:req.body.date2,
        time:req.body.time,
    }).then(()=>{
        console.log('data updated');
        
    
       return res.redirect('/')
    }); 
})
app.get('/back',(req,res)=>{
    res.render('index')
})





app.listen(port,()=>{
    console.log("Server Started At :-"+port);
})