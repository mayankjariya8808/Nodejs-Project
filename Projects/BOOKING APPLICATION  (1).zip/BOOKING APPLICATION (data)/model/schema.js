const mongoose=require('mongoose')
const BookingSchema=mongoose.Schema({
    name:{
        type:String,
        require:true
    },
    mobile:{
        type:String,
        require:true
    },
    pickup:{
        type:String,
        require:true
    },
    date1:{
        type:String,
        require:true
    },
    date2:{
        type:String,
        require:true
    },
    drop:{
        type:String,
        require:true
    },
    time:{
        type:String,
        require:true
    },
})
const schema=mongoose.model("BookingSchema",BookingSchema)
module.exports=schema;