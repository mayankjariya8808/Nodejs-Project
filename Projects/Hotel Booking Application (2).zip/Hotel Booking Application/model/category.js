const mongoose=require('mongoose')
const category=mongoose.Schema({
    house:{
        type:String,
    }
})
const table3=mongoose.model('table3',category)
module.exports=table3