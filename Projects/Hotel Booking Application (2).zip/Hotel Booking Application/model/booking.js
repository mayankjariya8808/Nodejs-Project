
const mongoose=require('mongoose')
const bookingSchema=mongoose.Schema({
   cusId:{type:mongoose.Schema.Types.ObjectId,ref:'table'},
       name:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    checkin:{
        type:String,
        required:true
    },
    checkout:{
        type:String,
        required:true
    },
    guest:{
        type:String,
        required:true
    },
    room:{
        type:String,
        required:true
    },
    category:{
        type:String,
        required:true
    },
    image:{
        type:String,
        required:true
    },
})
const table2=mongoose.model('table2',bookingSchema)
module.exports=table2