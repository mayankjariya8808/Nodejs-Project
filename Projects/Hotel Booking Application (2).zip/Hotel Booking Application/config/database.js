const mongoose=require('mongoose')
mongoose.connect('mongodb://127.0.0.1/HotelBooking')
const db=mongoose.connection
db.on('connected',()=>{
    console.log('DataBase Connected');
})
module.exports=db