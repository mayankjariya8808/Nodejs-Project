const express=require('express')
const port=8808;
const app=express()
const path=require('path')
const fs=require('fs')
const multer=require('multer')
const bcrypt=require('bcrypt')
const nodemailer=require('nodemailer')
const database=require('./config/database')
const schema=require('./model/cus-Signup')
const bookingSchema=require('./model/booking')
const category=require('./model/category')

app.use(express.urlencoded())
app.use(express.static(path.join(__dirname,"public")))
app.use('/uploads',express.static(path.join(__dirname,"uploads")))
const storage=multer.diskStorage({
    destination:(req,res,cb)=>{
        cb(null,'./uploads')
    },
    filename:(req,file,cb)=>{
        cb(null,file.originalname)
    }
})
    const image=multer({storage:storage}).single('image')
    const  sendmail=async(req,res)=>{

        const transporter=nodemailer.createTransport({
        
            service: 'gmail',
             auth:{
        
                user:"mkrajput8808@gmail.com",
                pass:"tcqduqssjzttzdnv",
        
        
             },
        });
        
        const info=await transporter.sendMail({
            from:"mkrajput8808@gmail.com",
            to:req.body.email,
            subject:"text",
            text:"Your booking Is Successfully Confirm At Sona booking Platform thanks for booking" 
    
        })
        res.redirect('/')
    }
    
    
    
    


    app.set('view engine','ejs')
    
app.get('/',(req,res)=>{
    category.find({}).then((alldata)=>{
        res.render('home',{
            record:alldata
        })
    })
})

app.get('/rooms',(req,res)=>{
    res.render('rooms')
})
app.get('/about-us',(req,res)=>{
    res.render('about-us')
})

app.get('/room-details',(req,res)=>{
    res.render('room-details')
})
app.get('/blog',(req,res)=>{
    res.render('blog')
})

app.get('/contact',(req,res)=>{
    res.render('contact')
})

app.get('/blog-details',(req,res)=>{
    res.render('blog-details')
})

app.get('/signup',(req,res)=>{
    res.render('signup')
})
app.get('adminpannel',(req,res)=>{
    bookingSchema.find({}).then((alldata)=>{
        res.render('adminpannel',{
            data2:alldata
        })
    })
})
app.get('/login',(req,res)=>{
    res.render('login')
})
app.post('/signup',async(req,res)=>{
        
        const data={
            username:req.body.username,
            phone:req.body.phone,
            email:req.body.email,
            password:req.body.password,
        }
        const existingData=await schema.findOne({email:data.email})
        if(existingData){
            res.send("User Already Define")
        }
        else{
            const saltRounds=10;
            const hexaPassword=await bcrypt.hash(data.password,saltRounds)
            data.password=hexaPassword;
            
            schema.create(data)
            console.log(data);
            res.redirect('login')
        }
    })
    app.post('/login',async(req,res)=>{
        if(req.body.email=="mkrajput@gmail.com" && req.body.password=="admin8808"){
            res.render('adminpannel')
        }
        else{

            try{
                const checkemail=await schema.findOne({email:req.body.email})
                if(!checkemail){
                    res.send('please Enter Valid EmailId')
                }
                const checkpassword=await bcrypt.compare(req.body.password,checkemail.password)
                if(checkpassword){
                    res.render('home')
                }
                else{
                    res.send('please Enter valid Password')
                }
            }
            catch{
                res.send('Invalid Details')
            }
        }
    })

    app.post('/booking',image,(req,res)=>{
        let image=""
        if(req.file){
            image=req.file.path
        }
        bookingSchema.create({
            name:req.body.name,
            email:req.body.email,
        checkin:req.body.checkin,
        checkout:req.body.checkout,
        category:req.body.category,
        guest:req.body.guest,
        room:req.body.room,
        image:req.file.path,
        })
        res.redirect('confirmation')
    })
    app.get('/tnku',(req,res)=>{
        res.redirect('/')
    })
    app.get('/confirmation',(req,res)=>{
        res.render('confirmation')
    })
    app.get('/view',(req,res)=>{
        bookingSchema.find({}).then((alldata)=>{
            res.render('view',{
                data:alldata
            })
        })
    })
    app.get('/back',(req,res)=>{
        res.render('adminpannel')
    })
    app.get('/manage',(req,res)=>{
        res.render('manage')
    })
    
    app.get('/adminpannel',(req,res)=>{
        res.render('adminpannel')
    })
    app.post('/main-category',(req,res)=>{
        category.create({
            house:req.body.house
        })
          
        res.redirect('adminpannel')
    })
app.listen(port,()=>{
    console.log("Server Started At : -" + port);
})