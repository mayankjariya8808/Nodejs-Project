const table=require('../model/schema')
const session=require('express-session')
const passport=require('passport')

const LocalStrategy=require('passport-local').Strategy
const localAuth=(passport)=>{
    passport.use(new LocalStrategy(async(username,password,done)=>{
        console.log("123")
        let user=await table.findOne({email:username})
        if(!user){
            return done(null,false)
        }
        if(user.password!=password){
            return done(null,false)
        }
        return done(null,user)
    })
)
passport.serializeUser((user,done)=>{
    return done(null,user.id)
})
passport.deserializeUser(async(id,done)=>{
let userr=await table.findById(id)
    return done(null,id)
})
}

module.exports=localAuth;





