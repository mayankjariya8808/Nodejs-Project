const express=require('express')
const port=8484;
const app=express()
const path=require('path')
const passport=require('passport')
const session=require('express-session')
// const flash=require('connect-flash')

const localAuth=require('./middleware/authentication')
app.use(express.static(path.join(__dirname,"public")))
app.use(session({secret:"private-key"}))

app.use(express.urlencoded())
const database=require('./config/database')
const schema=require('./model/schema')
const clientSchema=require('./model/client')
app.use(passport.initialize())
app.use(passport.session())

localAuth(passport)

app.set('view engine','ejs')

app.post('/signin',(req,res)=>{
    schema.create(req.body)
    res.redirect('login')
})
app.post('/login',passport.authenticate('local'),(req,res)=>{
    res.render('homepage')
})
app.get("/",(req,res)=>{

    res.render("signin")
    
    })
app.get("/login",(req,res)=>{

    res.render("login")
    
    })
    
    app.get("/change",(req,res)=>{
    
        res.render("change")
        
        })
    
    
    
    
    
    app.post('/change',async(req,res)=>{
    
        const email=req.body.email;
    
        const npassword=req.body.npassword;
    
    
        const data=await schema.findOne({email:email});
    
        if (data) {
    
            const id=data.id;
            console.log(id);
        
            
            const user=await schema.findByIdAndUpdate(id,{password:npassword})
    
            schema.create(user)
            
    
    
        }
        res.redirect('/login')
    
    
    
    
    })

app.get('/homepage',(req,res)=>{
    res.render('homepage')
})
    app.post('/appointment',(req,res)=>{
        clientSchema.create(req.body)
        console.log(req.body)
        res.redirect('homepage')
    })
    app.get('/admin',(req,res)=>{
        res.render('adminLogin')
    })

app.get('/homepage2',(req,res)=>{
    res.render('homepage2')
})
    
    app.post('/alogin',(req,res)=>{
        
        
        const data2={
            username:req.body.username,
            password:req.body.password
        }
        if(data2.username=="Admin" && data2.password=="8808"){
            res.redirect('/homepage2')
        }
        else{
            res.send("unvalid Details")
        }    
    
    })
    app.get('/view',(req,res)=>{
        clientSchema.find({}).then((alldata)=>{
            res.render('view',{
                data:alldata
            })
        })
    })
    app.get('/home',(req,res)=>{
        res.render('homepage2')
    })
    app.get('/logout',(req,res)=>{
        res.render('homepage')
    })
app.listen(port,()=>{
    console.log("Server started At:-"+port);
})