
const mongoose=require('mongoose')
mongoose.connect('mongodb://127.0.0.1/ERP')
const db=mongoose.connection;
db.on('connected',()=>{
    console.log('DataBase Has Been Connected');
})
module.exports=db;