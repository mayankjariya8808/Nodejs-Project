const express=require('express')
const port=7777;
const app=express()
const path=require('path')
const fs=require('fs')
const database=require('./config/database')
const StudentERP=require('./model/schema')
const multer=require('multer')
app.use('/upload',express.static(path.join(__dirname,"./upload")))
const storage=multer.diskStorage({
    destination:(req,res,cb)=>{
        cb(null,'./upload')
    },
    filename:(req,file,cb)=>{
        cb(null,file.originalname)
    }
})
const image=multer({storage:storage}).single('profile')

app.use(express.urlencoded())
// app.use('/',express.static(path.join(__dirname,"public")))
app.set('view engine','ejs')
app.get('/',(req,res)=>{
    res.render('index')
})
app.post('/insert',image,(req,res)=>{
    // let id=req.body.id;
    let profile=" "
    if(req.path){
        profile=req.file.path;
    }
    StudentERP.create({
        name:req.body.name,
        surname:req.body.surname,
        course:req.body.course,
        grid:req.body.grid,
        email:req.body.email,
        profile:profile

    })
    res.redirect('/')
})
app.get('/data',(req,res)=>{

    StudentERP.find({}).then((alldata)=>{
        res.render('view',{
            data:alldata
        })
    })
    
})

app.get('/delete',(req,res)=>{
    let id=req.query.id;
    StudentERP.findById(id).then((deletdata)=>{
        fs.unlinkSync(deletdata.profile)
    })

    StudentERP.findByIdAndDelete(id).then(()=>{
        res.redirect('view')
    })
})
app.get('/edit',(req,res)=>{
    let id=req.query.id
    StudentERP.findById(id).then((alldata)=>{
        // fs.unlinkSync(alldata.image)
        res.render('edit',{
            editData:alldata
        })
    })
})


app.post('/update',(req,res)=>{
    let id=req.body.id
    if(req.file){
        var updatedata={
            name:req.body.name,
        surname:req.body.surname,
        email:req.body.email,
        course:req.body.course,
        grid:req.body.grid,
        profile:req.file.path
        }
        
    }
    else{
     var updatedata={
        name:req.body.name,
        surname:req.body.surname,
        email:req.body.email,
        course:req.body.course,
        grid:req.body.grid,
        
     }       
    }
    StudentERP.findByIdAndUpdate(id,updatedata).then(()=>{
        console.log('data updated');
        
    
       return res.redirect('/')
    }); 
})








app.listen(port,()=>{
    console.log("Server Started At:"+port);
})