const mongoose=require('mongoose')
const StudentERP=mongoose.Schema({
    name:{
        type:String,
        require:true
    },
    surname:{
        type:String,
        require:true
    },
    course:{
        type:String,
        require:true
    },
    email:{
        type:String,
        require:true
    },
    profile:{
        type:String,
        require:true
    },
    grid:{
        type:String,
        require:true
    },
})
const schema=mongoose.model("StudentsERP",StudentERP)
module.exports=schema;