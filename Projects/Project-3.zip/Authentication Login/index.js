const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');

const database = require('./config/database');
const table = require('./model/schema');
const data=require('./model/data')

const app = express();
const port = 8808;

app.use(cookieParser());

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded());

app.set('view engine', 'ejs');
app.get('/', (req, res) => {
    res.render('login');
});

app.post('/insert', async (req, res) => {
    const data = await table.create(req.body);
    console.log(data);
    res.cookie("logged", data.id); 
    res.redirect('home'); 
});


const auth = async (req, res, next) => {
    let { logged } = req.cookies;

    if (logged) {
        const user = await table.findById(logged);
        if (user) {
            console.log(user);
            next(); 
        } else {
            res.send("User not exist.");
        }
    } else {
        res.send("User not logged in.");
    }
};

app.get('/home', auth, (req, res) => {
    res.render('home'); 
});
app.get('/blog',(req,res)=>{
    res.render('blog')
})
app.get('/view',(req,res)=>{
    data.find({}).then((alldata)=>{
        res.render('view',{
            data:alldata
        })
    })
})
app.post('/insert1',(req,res)=>{
    data.create({
        movie:req.body.movie,
        director:req.body.director,
        actor:req.body.actor,
        date:req.body.date,
        category:req.body.category,
        poster:req.body.poster
    })
    res.redirect('blog')

})

app.get('/delete',(req,res)=>{
    
    let id=req.query.id;
    data.findByIdAndDelete(id).then(()=>{
        res.redirect('view')
    })
})
app.get('/edit',(req,res)=>{
    
    let id=req.query.id;
    data.findByIdAndDelete(id).then(()=>{
        res.redirect('blog')
    })
})
app.get('/back',(req,res)=>{
    res.render('home')
})


app.post('/update',(req,res)=>{
    let id=req.body.id
    data.findByIdAndUpdate(id,{
        movie:req.body.movie,
        director:req.body.director,
        actor:req.body.actor,
        date:req.body.date,
        category:req.body.category,
    }).then(()=>{
        console.log('data updated');
        
    
       return res.redirect('/')
    }); 
})


app.get('/home',(req,res)=>{
    res.render('home')
})

app.listen(port, () => {
    console.log("Port... " + port);
});
