const mongoose=require('mongoose')
const schema=mongoose.Schema({
    movie:{
        type:String,
        require:true
    },
    actor:{
        type:String,
        require:true
    },
    director:{
        type:String,
        require:true
    },
    date:{
        type:String,
        require:true
    },
    category:{
        type:String, 
        require:true
    },
    poster:{
        type:String,
        require:true
    },
})

const table=mongoose.model('table',schema)
module.exports=table;