const express=require('express')
const port=8889;
const app=express()
const path=require('path')
const session=require('express-session')
app.use(session({secret:"privet-key"}))
const multer=require('multer')
const passport=require('passport')
const localauth=require('./middleware/authentication')
localauth(passport)
app.use(express.urlencoded())
app.use(express.static(path.join(__dirname,"public")))

app.use(passport.initialize())
app.use(passport.session())
const database=require('./config/database')
const table=require('./model/signup')
const table2=require('./model/login')
const mainCategory=require('./model/maincategory')
const sub=require('./model/subcategories')
const job=require('./model/add')
const apply=require('./model/apply')
const storage=multer.diskStorage({
    destination:(req,res,cb)=>{
        cb(null,'./uploads')
    },
    filename:(req,file,cb)=>{
        cb(null,file.originalname)
    }
})
const image=multer({storage:storage}).single('image')
app.post('/login',passport.authenticate('local'),(req,res)=>{
    res.render('user')
})
app.get('/admin',(req,res)=>{
    res.render('admin')
})
app.post('/admin',(req,res)=>{
    if(req.body.username=="admin8808@gmail.com" && req.body.password=="8808"){
        res.render('home')
    }
    else{
        res.send('Please Enter Valid Details')
    }
})
app.set('view engine','ejs')

app.get('/',(req,res)=>{
    res.render('signup')
})
app.get('/login',(req,res)=>{
    res.render('login')
})
app.get('/view',(req,res)=>{
  table.find({}).then((alldata)=>{
    res.render('view',{
        data:alldata
    })
    // res.redirect('back')
  })  
})

app.get('/home',(req,res)=>{
    res.render('home')
})
app.post('/signup',image,(req,res)=>{
    let image=""
    if(req.file){
        image=req.file.path
    }
    
    table.create({
        name:req.body.name,
        image:req.file.path,
        username:req.body.username,
        password:req.body.password,
    })
    console.log(req.body);
    res.redirect('login')
})
app.get('/profile',async(req,res)=>{
    res.render('profile')
})
app.get('/categories',(req,res)=>{
    res.render('categories')
})
app.post('/category',(req,res)=>{

    mainCategory.create({


        mainCategory:req.body.mainCategory
    })

    res.redirect('subcategories')

})
app.get('/subcategories',(req,res)=>{
    mainCategory.find({}).then((alldata)=>{
        res.render('subcategories',{
            record:alldata
        })
    })
})
app.post('/subCategory',(req,res)=>{
    sub.create({
        maincategoriesId:req.body.maincategoriesId,
        subCategory:req.body.subCategory
    })
    res.redirect('home')
})
app.get('/addjobs',(req,res)=>{
    mainCategory.find({}).then((alldata)=>{
        res.render('addjobs',{
            record:alldata
        })
    })
})
app.post('/add',(req,res)=>{
    job.create({
        company:req.body.company,
        mainCategory:req.body.mainCategory,
        link:req.body.link,
        salary:req.body.salary,
        hr:req.body.hr,
        type:req.body.type,
        about:req.body.about
    })
    res.redirect('home')
})
app.post('/applyjob',(req,res)=>{
    
    apply.create({
        fname:req.body.fname,
        lname:req.body.lname,
        email:req.body.email,
        job:req.body.job,
        mob:req.body.mob,
        links:req.body.links
    })
    res.redirect('confirm')
})
app.get('/apply',(req,res)=>{
    res.render('apply')
})
app.get('/logout',(req,res)=>{
    res.render('login')
})
app.get('/find',(req,res)=>{
    job.find({}).then((alldata)=>{
        res.render('find',{
            jobdata:alldata
        })
    })
})


app.get('/confirm',(req,res)=>{
    res.render('confirm')
})
app.get('/back',(req,res)=>{
    res.render('user')
})
app.get('/vacancy',(req,res)=>{
    apply.find({}).then((alldata)=>{
        res.render('vacancy',{
            userData:alldata
        })
        res.redirect('home')
    })
})
app.get('/logoutt',(req,res)=>{
    res.render('signup')
})
app.listen(port,()=>{
    console.log("Server Started At:-"+port);
})