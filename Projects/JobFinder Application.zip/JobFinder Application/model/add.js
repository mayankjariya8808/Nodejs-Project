const mongoose=require('mongoose')
const schema=mongoose.Schema({
    company:{
        type:String,
        require:true
    },
    mainCategoryId:{
        type:String,
        require:true
    },
    links:{
        type:String,
        require:true
    },
    salary:{
        type:String,
        require:true
    },
    
    hr:{
        type:String,
        require:true
    },
    type:
    {
        type:String,
        require:true
    }
    
    

    

})
const addjobs=mongoose.model('addjobs',schema)
module.exports=addjobs;