const mongoose=require('mongoose')
const schema=mongoose.Schema({
    fname:{
        type:String,
        require:true
    },
    lname:{
        type:String,
        require:true
    },
    email:{
        type:String,
        require:true
    },
    mob:{
        type:String,
        require:true
    },
    
    job:{
        type:String,
        require:true
    },
    links:
    {
        type:String,
        require:true
    }
    
    

    

})
const apply=mongoose.model('appply',schema)
module.exports=apply;