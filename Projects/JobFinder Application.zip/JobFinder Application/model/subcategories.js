const mongoose=require('mongoose')
const schema=mongoose.Schema({
    maincategoriesId:{type:mongoose.Schema.Types.ObjectId,ref:"category"},
    subCategory:{
        type:String,
        required:true
    }
})
const subcategories=mongoose.model('subcategories',schema)
module.exports=subcategories;