const mongoose=require('mongoose')
const login=mongoose.Schema({
    username:{
        type:String,
        require:true
    },

})
const table2=mongoose.model('table2',login)
module.expo=table2