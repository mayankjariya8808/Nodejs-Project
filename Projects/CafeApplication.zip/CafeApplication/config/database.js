const mongoose=require('mongoose')
mongoose.connect('mongodb://127.0.0.1/OtpAuth')
const db=mongoose.connection;
db.on('connected',()=>{
    console.log("Database Connected");
})
module.exports=db;