const mongoose=require('mongoose')
const schema2=mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    phone:{
        type:String,
        required:true
    },
    date:{
        type:String,
        required:true
    },
    time:{
        type:String,
        required:true
    },

    people:{
        type:String,
        required:true
    }
})
const table2=mongoose.model('table2',schema2)
module.exports=table2;