const express=require('express')
const port=8686;
const app=express()
const path=require('path')
const session=require('express-session')
const flash=require('connect-flash')
app.use(session({secret:"privet-key"}))
app.use(flash())
const nodemailer=require('nodemailer')
const table=require('./model/schema')
const table2=require('./model/table2')
app.use(express.static(path.join(__dirname,"public")))
const Database=require('./config/database')
app.use(express.urlencoded())
const otp=Math.floor(Math.random()*10000)






app.set('view engine','ejs')
const  sendmail=async(req,res)=>{

    const transporter=nodemailer.createTransport({
    
        service: 'gmail',
         auth:{
    
            user:"faisalbadi57@gmail.com",
            pass:"ymlsdfyrzbowplto",
    
    
         },
    });
    const info=await transporter.sendMail({
        from:"mkrajput8808@gmail.com",
        to:req.body.email,
        subject:"OTP",
        html:`${otp}`

    })
    res.redirect('otplogin')
}




const verify=async (req,res)=>{
    let token=req.body.otp;

    if(token==otp){
        res.render('home')
    }
    else{
        res.send("please Enter Valid Details")
    }
}

app.post('/otp',sendmail)
app.post('/confirmm',verify)
app.get('/otplogin',(req,res)=>{
    res.render('otplogin')
})
app.get('/',(req,res)=>{
    res.render('index')
})
app.get('/home',(req,res)=>{
    res.render('home')
})
app.get('/login',(req,res)=>{
    res.render('login')
})
app.post('/insert',(req,res)=>{
    table.create(req.body)
    console.log(req.body)
    res.redirect('login')
})
app.get('/confirmation',(req,res)=>{
    res.render('confirmation')
})
app.post('/bookingDetails',(req,res)=>{
    
        
    table2.create(req.body)
    console.log(req.body)
    res.redirect('confirmation')
})
app.get('/management',(req,res)=>{
    res.render('management')
})
app.post('/management',(req,res)=>{
    if(req.body.email=="mk88" && req.body.password=="8880"){
        res.render('home2')
    }
    else{
        res.send("Inncorrect Details")
    }
})
app.get('/home2',(req,res)=>{
    res.render('home2')
})
app.get('/view',(req,res)=>{
    table2.find({}).then((alldata)=>{
        res.render('view',{
            data:alldata
        })
    })
})
app.get('/delete',(req,res)=>{
    let id=req.query.id;
    table2.findByIdAndDelete(id).then(()=>{
        res.redirect('view')
    })
    
})
app.get('/back',(req,res)=>{
    res.render('home2')
})
app.get('/back2',(req,res)=>{
    res.render('home')
})
app.get('/logout',(req,res)=>{
    res.render('home')
})
app.get('/userlogin',(req,res)=>{
    res.render('login')
})
app.listen(port,()=>{
    console.log("Sever Started At:-"+port);
})