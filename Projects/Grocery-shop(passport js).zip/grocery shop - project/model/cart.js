const mongoose=require('mongoose')
const cartTable=mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    item:{
        type:String,
        required:true
    },
    address:{
        type:String,
        required:true
    }
})
const carttable=mongoose.model('carttable',cartTable)
module.exports=carttable;