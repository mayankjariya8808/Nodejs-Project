const express=require('express')
const port=8889;
const app=express()
const path=require('path')
const session=require('express-session')
app.use(session({secret:"privet-key"}))
const passport=require('passport')
const localauth=require('./middleware/localauth')
localauth(passport)
app.use(express.urlencoded())
app.use(express.static(path.join(__dirname,"public")))

app.use(passport.initialize())
app.use(passport.session())
const database=require('./config/database')
const table=require('./model/schema')
const cartTable=require('./model/cart')

app.post('/login',passport.authenticate('local'),(req,res)=>{
    res.render('homepage')
})

app.set('view engine','ejs')

app.get('/',(req,res)=>{
    res.render('signup')
})
app.get('/login',(req,res)=>{
    res.render('login')
})
app.get('/homepage',(req,res)=>{
    res.render('homepage')
})
app.post('/signin',(req,res)=>{
    table.create(req.body)
    console.log(req.body);
    res.redirect('login')
})
app.get('/feedback',(req,res)=>{
    res.render('feedback')
})
app.get('/shopnow',(req,res)=>{
res.render('sellerLogin')
})
app.post('/sellerlogin',(req,res)=>{
    cartTable.create(req.body)
})
app.get('/cart',(req,res)=>{
    cartTable.find({}).then((alldata)=>{
        res.render('cart',{
            cartData:alldata
        })
    
    })

})
app.get('/place',(req,res)=>{
    res.render('confirm')
})
app.get('/back',(req,res)=>{
    res.render('homepage')
})
app.get('/delete',(req,res)=>{
    let id=req.query.id;
    cartTable.findByIdAndDelete(id).then(()=>{
        res.redirect('homepage')
    })
    
})
app.get('/logout',(req,res)=>{
    let id=req.query.id;
    table.findByIdAndDelete(id).then(()=>{
        res.redirect('login')
    })
})

app.listen(port,()=>{
    console.log("Server Started At:-"+port);
})