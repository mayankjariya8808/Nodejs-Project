const mongoose=require('mongoose')
const schema=mongoose.Schema({
    name:{
        type:String,
        require:true
    },
    auther:{
        type:String,
        require:true
    },
    price:{
        type:Number,
        require:true
    }
})
const bookSchema=mongoose.model("books",schema)
module.exports=bookSchema