const express=require('express')
const port=4200;
const app=express()
const path=require('path')
const dataBase=require('./config/database')
const bookSchema=require("./model/schema")


app.use(express.urlencoded())
app.use('/',express.static(path.join(__dirname,"public")))
app.set('view engine','ejs')
app.get('/',(req,res)=>{

    bookSchema.find({}).then((alldata)=>{

        res.render("index",{
            data:alldata
        });

    })
})

app.post('/insert',(req,res)=>{
    bookSchema.create({
        name:req.body.name,
        auther:req.body.auther,
        price:req.body.price,
    })
    res.redirect('/')
})
app.get('/delete',(req,res)=>{
    
    let id=req.query.id;
    bookSchema.findByIdAndDelete(id).then(()=>{
        res.redirect('/')
    })
})
app.get('/edit',(req,res)=>{
    let id=req.query.id
    bookSchema.findById(id).then((alldata)=>{
        res.render('edit',{
            editData:alldata
        })
    })
})

app.post('/update',(req,res)=>{
    let id=req.body.id
    bookSchema.findByIdAndUpdate(id,{
        name:req.body.name,
        auther:req.body.auther,
        price:req.body.price
    }).then(()=>{
        console.log('data updated');
        
    
       return res.redirect('/')
    }); 
})




app.listen(port,()=>{
    console.log("server Has Been Created At:-"+port);
})
