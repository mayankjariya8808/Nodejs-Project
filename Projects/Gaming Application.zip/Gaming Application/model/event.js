const mongoose=require('mongoose')
const schema=mongoose.Schema({
    eventName:{
        type:String,
        required:true
    },
    org:{
        type:String,
        required:true
    },
    price:{
        type:String,
        required:true
    },
    image:{
        type:String,
        required:true
    },
    date:{
        type:String,
        required:true
    },
    
})
const event=mongoose.model('event',schema)
module.exports=event