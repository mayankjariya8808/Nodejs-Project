const mongoose=require('mongoose')
const schema=mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    username:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    dob:{
        type:String,
        required:true
    },
    mob:{
        type:String,
        required:true
    },
})
const signup=mongoose.model('signup',schema)
module.exports=signup