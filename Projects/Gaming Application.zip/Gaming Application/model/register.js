const mongoose=require('mongoose')
const schema=mongoose.Schema({
    email:{
        type:String,
        required:true
    },
    mob:{
        type:String,
        required:true
    },
    sname:{
        type:String,
        required:true
    },
    gid:{
        type:String,
        required:true
    }
})
const register=mongoose.model('register',schema)
module.exports=register