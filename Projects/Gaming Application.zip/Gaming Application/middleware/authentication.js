const schema=require('../model/signupSchema')
const session=require('express-session')
const passport=require('passport')
const LocalStretagy=require('passport-local').Strategy
const localAuth=(passport)=>{
    passport.use(new LocalStretagy(async(username,password, done)=>{
        let user=await schema.findOne({username:username})
        if(!user){
            return done(null,false)
        }
        if(user.password!=password){
            return done(null,false)
        }
        return done(null,user)
    }))
    passport.serializeUser((user,done)=>{
        return done(null,user.id)
    })
    passport.deserializeUser(async(id,done)=>{
        let user=await schema.findById(id)
        return done(null,user)
    })
}
module.exports=localAuth;