const express=require('express')
const port=8808;
const app=express()
const path=require('path')
const fs=require('fs')
const multer=require('multer')
const passport=require('passport')
const session=require('express-session')
const localAuth=require('./middleware/authentication')
app.use(express.static(path.join(__dirname,"public")))
app.use(session({secret:"private-key"}))
app.use(express.urlencoded())
const database=require('./config/database')
const schema=require('./model/signupSchema')
const eventSchema=require('./model/event')
const register=require('./model/register')
app.use(passport.initialize())
app.use(passport.session())
localAuth(passport)
app.use('/upload',express.static(path.join(__dirname,"upload")))
const storage=multer.diskStorage({
    destination:(req,res,cb)=>{
        cb(null,'./upload')
    },
    filename:(req,file,cb)=>{
        cb(null,file.originalname)
    }
})
const image=multer({storage:storage}).single('image')
app.set('view engine','ejs')
const admin=(req,res,next)=>{
    if(req.body.email=="mkrajput3173@gmail.com" && req.body.password=="3173"){
        next()
    }
}

app.get('/',(req,res)=>{
    res.render('signup')
})

app.post('/signup',(req,res)=>{
    schema.create({
        name:req.body.name,
        username:req.body.username,
        mob:req.body.mob,
        dob:req.body.dob,
        password:req.body.password,
    })
    res.redirect('login')
})
app.get('/login',(req,res)=>{
    res.render('login')
})
app.get('/index',(req,res)=>{
    res.render('index')
})
app.get('/review',(req,res)=>{
    res.render('review')
})
app.get('/categories',(req,res)=>{
    res.render('categories')
})
app.get('/community',(req,res)=>{
    res.render('community')
})
app.get('/contact',(req,res)=>{
    res.render('contact')
})
app.get('/events',(req,res)=>{
    eventSchema.find({}).then((alldata)=>{
        res.render('events',{
            data:alldata
        })
    })
})
app.get('/admin',(req,res)=>{
    res.render('admin')
})
app.get('/adminpannel',(req,res)=>{
    res.render('adminpannel')
})
app.post('/admin',admin,(req,res)=>{
    res.redirect('adminpannel')
    
})
app.get('/addevent',(req,res)=>{
    res.render('addevent')
})
app.post('/event',image,(req,res)=>{
    let image=""
    if(req.file){
        image=req.file.path
    }
   
    eventSchema.create({
        eventName:req.body.eventName,
        date:req.body.date,
        org:req.body.org,
        price:req.body.price,
        image:image,
        about:req.body.about,
    })
    res.redirect('adminpannel')
})
app.get('/logout',(req,res)=>{
    res.render('index')
})
app.get('/register',(req,res)=>{
    res.render('register')
})
app.post('/register',(req,res)=>{
    register.create({
        email:req.body.email,
        sname:req.body.sname,
        mob:req.body.mob,
        gid:req.body.gid,
    })
    res.redirect('confirmation')
})
app.get('/confirmation',(req,res)=>{
    res.render('confirmation')
})
app.get('/userinfo',(req,res)=>{
    register.find({}).then((alldata)=>{
        res.render('userinfo',{
            record:alldata
        })
    })
})
app.get('/back',(req,res)=>{
    res.redirect('adminpannel')
})
app.post('/login',passport.authenticate('local'),(req,res)=>{
    res.render('index')
})
app.listen(port,()=>{
    console.log("Server Started At:-" + port);
})